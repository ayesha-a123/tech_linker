package com.example.tech_linker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
