import 'package:flutter/material.dart';
import 'package:tech_linker/Splash_ScreenThree.dart';
import 'package:tech_linker/Splash_ScreenTwo.dart';


class ScreenTwo extends StatelessWidget {
  const ScreenTwo({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 50,
            ),
            Center(
              child: Text('Discover The \n  Right Internship',style: TextStyle(color: Colors.white,fontSize: 45,
              ),textAlign: TextAlign.center,
              ),
            ),
                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: Center(
                    child: Image.asset('assets/techLink.png',
                    width: 300,
                    height: 300,),
                  ),
                ),
            SizedBox(
              height: 30,
            ),
            Center(child: Text('Match your skills with top\nsoftware houses\nand institutes',style: TextStyle(color: Colors.white,fontSize: 25),textAlign: TextAlign.center,),),
            SizedBox(
              height: 70,
            ),
            Center(child:ElevatedButton(onPressed: (){
              Navigator.of(context).push(MaterialPageRoute(builder: (context)=>ScreenThree()));
            },
                child: Text('Lets Get Started',style: TextStyle(color: Colors.black,fontSize:20),))),
          ],
        ),
      ),
    );

  }
}
