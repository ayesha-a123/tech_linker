import 'package:flutter/material.dart';
import 'package:tech_linker/Splash_screenOne.dart';
import 'package:tech_linker/Splash_ScreenTwo.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        builder: (context, child) {
          return Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF2A0845), Color(0xFF6441A5)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: child, // 👈 This will be every screen automatically
          );
        },
      home: ScreenOne(),
    );

  }
}

