import 'package:flutter/material.dart';
import 'package:tech_linker/SignIn_screen.dart';

class ScreenThree extends StatelessWidget {
  const ScreenThree({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
     backgroundColor: Colors.transparent,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 100),
            child: Text('Join a Growing\nTech Community',textAlign: TextAlign.center,style: TextStyle(fontSize: 45,color: Colors.white),),
          ),
          SizedBox(
            height: 60,
          ),
          Center(child: Image.asset('assets/techLinker.png',)),
          SizedBox(
            height: 30,
          ),
          Center(child: Text('Connect with mentor\nand like-minded learners',textAlign: TextAlign.center,style: TextStyle(color: Colors.white,fontSize: 30),)),
          SizedBox(
            height: 100,
          ),
          SizedBox(
            width: 180,
            height: 40,
            child: ElevatedButton(onPressed:(){
              Navigator.of(context).push(MaterialPageRoute(builder: (context)=>ScreenFour()));
            },
                child: Text('Create Account',style: TextStyle(fontSize: 18,color: Colors.black,fontWeight: FontWeight.bold),)),
          ),
        ],
      ),
    );
  }
}
