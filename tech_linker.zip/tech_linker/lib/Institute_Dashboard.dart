import 'package:flutter/material.dart';

class InstituteDashboard extends StatefulWidget {
  const InstituteDashboard({super.key});

  @override
  State<InstituteDashboard> createState() => _InstituteDashboardState();
}

class _InstituteDashboardState extends State<InstituteDashboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
