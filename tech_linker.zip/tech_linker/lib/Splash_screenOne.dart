import 'package:flutter/material.dart';
import 'package:tech_linker/Splash_ScreenTwo.dart';
class ScreenOne extends StatelessWidget {
  const ScreenOne({super.key});

  @override
  Widget build(BuildContext context) {
    double screenheight=MediaQuery.of(context).size.height;
    double screenwidth=MediaQuery.of(context).size.width;
    return Scaffold(
        body:Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF2A0845), Color(0xFF6441A5)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          
          child: Padding(
            padding: const EdgeInsets.only(top: 15.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      radius: 80,
                      backgroundImage: AssetImage('assets/techLogo.jpeg'),
                      
                    ),
                    // Image.asset('assets/techLogo.jpeg',
                    // width: 150,
                    // height: 150,
                    // ),
                    SizedBox(height: 20),
                    Text(' TechLinker', style: TextStyle(color: Colors.white, fontSize: 45,fontWeight: FontWeight.bold),),
                    SizedBox(
                      height: 10,
                    ),
                    Text('From dreams to direction',style: TextStyle(color: Colors.white,fontSize: 20,fontWeight: FontWeight.bold
                    ),),
                    SizedBox(
                      height: 10,
                    ),
                    Center(child: Text('  TechLinker is your guide.Explore internships that match \n           your goals and take charge of your career path',style: TextStyle(color: Colors.white,fontSize: 15),)),
                    SizedBox(
                      height: 150,
                    ),
                    SizedBox(
                      height: screenheight*0.05,
                      width: screenwidth*0.4,
                      child: ElevatedButton(onPressed: (){
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (context)=>ScreenTwo()),
                        );
                      }, child: Text('Get Started',style: TextStyle(fontSize: 18),)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),

    );
  }
}
